i worked on FordGoBike Dataset

- extraction of date and sperate the year , month , day in each column
- most of genders are subscriber not customer , and most of them are not in program of low income residents , which indicates that most of them are passionate about riding bikes 
- inspite of males are the more in riding bikes , the females have duration in riding bikes more than the males.

